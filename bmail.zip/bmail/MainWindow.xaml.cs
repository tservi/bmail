﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using Microsoft;
using System.Diagnostics;
using System.ComponentModel;

using Microsoft.Office.Interop.Outlook;
using OutlookApp = Microsoft.Office.Interop.Outlook.Application;

public static class GlobalVariables
{

    public static string htmlcode = @"

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>

<html xmlns='http://www.w3.org/1999/xhtml' >
<head><link href='http://magicquestion.corproot.net/MagicQuestion/Pages/Swisscom.css' rel='stylesheet' type='text/css' />
	
<meta name='Version' Content='1.0.0.95' /><title>
	CCAgent Magic Question
</title><style type='text/css'>
	/* <![CDATA[ */
	#ctl03 img.icon { border-style:none;vertical-align:middle; }
	#ctl03 img.separator { border-style:none;display:block; }
	#ctl03 img.horizontal-separator { border-style:none;vertical-align:middle; }
	#ctl03 ul { list-style:none;margin:0;padding:0;width:auto; }
	#ctl03 ul.dynamic { z-index:1; }
	#ctl03 a { text-decoration:none;white-space:nowrap;display:block; }
	#ctl03 a.static { padding-left:0.15em;padding-right:0.15em; }
	#ctl03 a.popout { background-image:url('Images/Down.gif');background-repeat:no-repeat;background-position:right center;padding-right:14px; }
	#ctl03 a.popout-dynamic { background:url('http://magicquestion.corproot.net/MagicQuestion/WebResource.axd?d=-7tBYU3ScPLKqJ-1ELzOh-9Zn_2Y0b8yg2OKqhsDrPU_N35UTL_sVbZJLbtCBZj4DRR24WG95frtAag1A6MIm-jo1BzOs908G1AF5Dx9T5s1&t=635661302788714647') no-repeat right center;padding-right:14px; }
	/* ]]> */
</style></head>
<body>
    <form method='post' action='http://magicquestion.corproot.net/MagicQuestion/CCAgent.aspx' id='form1' name='form1'>
<div class='aspNetHidden'>
<input type='hidden' name='__LASTFOCUS' id='__LASTFOCUS' value='' />
<input type='hidden' name='__EVENTTARGET' id='__EVENTTARGET' value='' />
<input type='hidden' name='__EVENTARGUMENT' id='__EVENTARGUMENT' value='' />
<input type='hidden' name='__VIEWSTATE' id='__VIEWSTATE' value='/wEPDwUJNzY4MzczOTM4D2QWAmYPZBYCAgMPZBYMAgMPDxYCHgdWaXNpYmxlaGRkAgUPDxYCHwBoZGQCBw8PFgIfAGhkZAIJDw8WAh8AaGRkAgsPDxYCHwBnZGQCEw9kFgICDQ8QDxYCHgtfIURhdGFCb3VuZGdkEBVjJTxub2JyPkFhcmdhdWlzY2hlIEthbnRvbmFsYmFuazwvbm9icj4pPG5vYnI+QUJTIEFsdGVybmF0aXZlIEJhbmsgU2Nod2Vpejwvbm9icj4iPG5vYnI+QWNjZW50dXJlIFNlcnZpY2VzIEFHPC9ub2JyPhw8bm9icj5hY3JldmlzIEJhbmsgQUc8L25vYnI+FTxub2JyPkFFSyBUaHVuPC9ub2JyPiM8bm9icj5BbHBoYSBSaGVpbnRhbCBCYW5rIEFHPC9ub2JyPhU8bm9icj5BbHBpcSBBRzwvbm9icj4SPG5vYnI+QXNjb208L25vYnI+FTxub2JyPkFWSUdBIEFHPC9ub2JyPhA8bm9icj5BWEE8L25vYnI+JDxub2JyPkJhbmsgYWVrIEdlbm9zc2Vuc2NoYWZ0PC9ub2JyPiQ8bm9icj5CYW5rIEJTVSBHZW5vc3NlbnNjaGFmdDwvbm9icj4hPG5vYnI+QmFuayBDQSBTdC5HYWxsZW4gQUc8L25vYnI+HDxub2JyPkJhbmsgQ29vcCAoQkNCKTwvbm9icj4VPG5vYnI+QmFuayBFRUs8L25vYnI+KDxub2JyPkJhbmsgSnVsaXVzIELDpHIgJiBDby4gTHRkLjwvbm9icj4YPG5vYnI+QmFuayBTTE0gQUc8L25vYnI+GTxub2JyPkJhbmsgVGhhbHdpbDwvbm9icj4vPG5vYnI+QmFucXVlIENhbnRvbmFsZSBkZSBHZW7DqHZlIChCQ0dFKTwvbm9icj4mPG5vYnI+QmFzbGVyIEthbnRvbmFsYmFuayAoQktCKTwvbm9icj4QPG5vYnI+QkJPPC9ub2JyPh88bm9icj5CZXJuZXJsYW5kIEJhbmsgQUc8L25vYnI+EDxub2JyPkJJUzwvbm9icj4dPG5vYnI+QktUIEJhbmsgVGhhbHdpbDwvbm9icj4TPG5vYnI+QkxTIEFHPC9ub2JyPhs8bm9icj5CU1BLIERpZWxzZG9yZjwvbm9icj4sPG5vYnI+QnVyZ2VybGljaGUgRXJzcGFybmlza2Fzc2UgQmVybjwvbm9icj4TPG5vYnI+Q2VydGFzPC9ub2JyPho8bm9icj5DcmVkaXQgU3Vpc3NlPC9ub2JyPho8bm9icj5EWiBQUklWQVRCQU5LPC9ub2JyPho8bm9icj5FSyBJbnRlcmxha2VuPC9ub2JyPhw8bm9icj5FSyBSw7xlZ2dpc2Jlcmc8L25vYnI+Hjxub2JyPkVudHJpcyBCYW5raW5nIEFHPC9ub2JyPhA8bm9icj5FT1M8L25vYnI+Fzxub2JyPkVxdWlsYXMgQUc8L25vYnI+Hzxub2JyPkVzcHJpdCBOZXR6d2VyayBBRzwvbm9icj4lPG5vYnI+RmluYW56ZGVwYXJ0ZW1lbnQgS3QuIEJTPC9ub2JyPh48bm9icj5GaW5hbnpsb2dpc3RpayBBRzwvbm9icj4UPG5vYnI+Rmlubm92YTwvbm9icj4kPG5vYnI+RnJlaWJ1cmdlciBLYW50b25hbGJhbms8L25vYnI+JTxub2JyPkdSQiBHbGFybmVyIFJlZ2lvbmFsYmFuazwvbm9icj4YPG5vYnI+R3JpZXNzZXIgQUc8L25vYnI+Gzxub2JyPkdTTU4gU3Vpc3NlIFNBPC9ub2JyPhY8bm9icj5IeXBvc3dpc3M8L25vYnI+EDxub2JyPklCTTwvbm9icj4aPG5vYnI+SUcgTGVhc2luZyBBRzwvbm9icj4jPG5vYnI+SUtFQSBTZXJ2aWNlIENlbnRlciBOVjwvbm9icj4jPG5vYnI+SW1wbGVuaWEgTWFuYWdlbWVudCBBRzwvbm9icj4UPG5vYnI+SW5mb25ldDwvbm9icj4dPG5vYnI+SW5zZWxzcGl0YWwgQmVybjwvbm9icj4YPG5vYnI+SVNTIFNjaHdlaXo8L25vYnI+Ezxub2JyPklULVNETDwvbm9icj4cPG5vYnI+SnVyYSBNYW5hZ2VtZW50PC9ub2JyPhA8bm9icj5LUFQ8L25vYnI+FDxub2JyPkxleG1hcms8L25vYnI+JTxub2JyPkxpZW5oYXJkIE9mZmljZSBHcm91cCBBRzwvbm9icj4tPG5vYnI+TGllbmhhcmQgdW5kIFBhcnRuZXIgUHJpdmF0YmFuayA8L25vYnI+FDxub2JyPkxvZWIgQUc8L25vYnI+Ijxub2JyPkx1emVybmVyIEthbnRvbmFsYmFuazwvbm9icj4pPG5vYnI+TWlyYWJhdWQgQXNzZXQgTWFuYWdlbWVudCBTQTwvbm9icj4VPG5vYnI+TW9iaWxpYXI8L25vYnI+Fzxub2JyPk1vZXZlbnBpY2s8L25vYnI+Fzxub2JyPlByZXZpb24gQUc8L25vYnI+Fjxub2JyPlByaW9yYSBBRzwvbm9icj4XPG5vYnI+UkJTIENvdXR0czwvbm9icj4YPG5vYnI+UmVzb3VyY2UgQUc8L25vYnI+EDxub2JyPlJTTzwvbm9icj4ePG5vYnI+U0IgU2FhbmVuIEJhbmsgQUc8L25vYnI+EDxub2JyPlNCQjwvbm9icj4mPG5vYnI+U2JlcmJhbmsgKFN3aXR6ZXJsYW5kKSBBRzwvbm9icj4sPG5vYnI+U2Nod2Vpei4gRGllbnN0bGVpc3R1bmdzemVudHJ1bTwvbm9icj4WPG5vYnI+U2VjdXJpdGFzPC9ub2JyPhY8bm9icj5TZWN1cml0b248L25vYnI+Fjxub2JyPlNlY3VyaXR1czwvbm9icj4RPG5vYnI+U0hPUDwvbm9icj4bPG5vYnI+U0wgQnVjaGVnZ2Jlcmc8L25vYnI+GDxub2JyPlNMIEZydXRpZ2VuPC9ub2JyPik8bm9icj5TcGFyK0xlaWhrYXNzZSBSaWdnaXNiZXJnIEFHPC9ub2JyPiA8bm9icj5TcGFya2Fzc2UgU2Nod3l6IEFHPC9ub2JyPiM8bm9icj5TcGFya2Fzc2UgV2llc2VuZGFuZ2VuPC9ub2JyPiM8bm9icj5TdC5HYWxsZXIgS2FudG9uYWxiYW5rPC9ub2JyPhU8bm9icj5Td2lzc2NvbTwvbm9icj4VPG5vYnI+U3dpc3Nsb3M8L25vYnI+Hjxub2JyPlN3aXNzcmVnaW9iYW5rIEFHPC9ub2JyPhQ8bm9icj5UYW1lZGlhPC9ub2JyPio8bm9icj5UaGUgU3dhdGNoIEdyb3VwIFNlcnZpY2VzIEx0ZDwvbm9icj4jPG5vYnI+VGh1cmdhdWVyIEthbnRvbmFsYmFuazwvbm9icj4TPG5vYnI+VFVTIEFHPC9ub2JyPhE8bm9icj5VRUZBPC9ub2JyPhE8bm9icj5VbmlhPC9ub2JyPhM8bm9icj5VbmlzeXM8L25vYnI+ITxub2JyPlVuaXZlcnNpdMOkdHMgU3BpdGFsPC9ub2JyPhA8bm9icj5VUFU8L25vYnI+LDxub2JyPlZlcndhbHR1bmdzLSB1bmQgUHJpdmF0LUJhbmsgQUc8L25vYnI+GTxub2JyPlZaIERlcG90YmFuazwvbm9icj4aPG5vYnI+V0VJRFBMQVMgR21iSDwvbm9icj4bPG5vYnI+V2ludGVydGh1ciBHJkQ8L25vYnI+FTxub2JyPldJUiBCYW5rPC9ub2JyPhc8bm9icj5YZW50aXZlIFNBPC9ub2JyPhVjAjY1AjQzAjg4AjgwAjMyAjU2AjkwATkCNjICNDYCMzUDMTA4AjU3Ajc2AjM2Ajc3AzEwOQIzMwI2NAI2MQIzNwMxMTACMjYCMzADMTA0AjM4AzEwNQE3AjE3Ajg0AjM5AjQwAjY2ATgDMTA2AjQ1AjczAjYwAjE2AjIxAzExMQI3NQMxMDMCMjMCMjICODECODUCNTIBNQI1NAIxNAIxMAI3NAIxMQI0OQI5MwMxMTkCODYCMjADMTAyAjU1AjUxAjI0AjkxAjI1AjYzAjM0AzExMwI0OAI4NwIxNQEyATMBNAE2AjQxAjQyAzEwNwMxMTICNTgCMTkBMQIyNwI1OQIxMwI3OQIxOAI4MwIyOAI1MwI1MAIyOQIzMQI0NwI0NAI5MgI4OQI3OAI4MhQrA2NnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dkZGTdBqjuyRsxuVdnCDKXy1YXbo13IbgmtN3XFe+cHlVrbw==' />
</div>

<div class='aspNetHidden'>

	<input type='hidden' name='__VIEWSTATEGENERATOR' id='__VIEWSTATEGENERATOR' value='094D066C' />
	<input type='hidden' name='__EVENTVALIDATION' id='__EVENTVALIDATION' value='/wEWaQL2iYGoDwK6itLoAgLktpHoAQKsmKWQDALLjp+4CgLMjoe4CgKF9u6aAwLKjp+4CgLOjs+7CgLNjpe4CgLoz8DvDQLIjp+4CgLKjq+4CgLOjuO7CgLZjsO7CgLPjpu4CgK7iK+sDwLPjpO4CgLPjoe4CgLZjqO4CgLMjqO4CgLPjpe4CgLWjq+4CgLKjs+7CgLMjqu4CgLUss3aAgLPjqu4CgLPjp+4CgLOjpe4CgLKjpu4CgLMjsO7CgLZjq+4CgLLjpe4CgLIjs+7CgLWjqO4CgLx3evxCALZjp+4CgLMjpO4CgLOjsO7CgLWjuO7CgLIjuO7CgLKjqu4CgK7iKusDwLZjpe4CgLLjqu4CgLOjoe4CgLKjuO7CgLNjsO7CgLPjsO7CgLNjpu4CgLZjpO4CgLKjpO4CgLZjoe4CgLKjpe4CgLMjp+4CgLMjs+7CgLOjpO4CgLOjp+4CgLKjqO4CgKQhdfFDALNjqO4CgLOjqO4CgLPjuO7CgLPjs+7CgLKjoe4CgLLjpu4CgLIjpO4CgLMjuO7CgLMjq+4CgLIjpu4CgLZjuO7CgLOjq+4CgLNjuO7CgLNjoe4CgLMjpu4CgKKxInsDgLNjs+7CgLLjuO7CgLNjpO4CgLIjoe4CgLNjp+4CgLWjpe4CgLNjq+4CgLWjqu4CgKtrPXwAgLIjpe4CgKtrPHwAgLNjqu4CgLZjs+7CgLMjpe4CgLLjqO4CgLZjpu4CgKn75ebBALIjsO7CgLLjpO4CgLOjpu4CgLPjqO4CgKe4YyxCQLZjqu4CgLLjq+4CgLPjq+4CgKe4YCxCQLKjsO7CgLB4cnVBgKK66SaDdUB3d90gyEavfwSjW7LUIrWPC49PMjfL7XGr/AkFgBd' />
</div>

    
    <div style='height:85px'>
    <table width='100%' cellpadding='0' cellspacing='0'>
    <tr>
    <td></td>
    <td class='tdcenter'><h1>Magic Question</h1></td>
    <td class='tdtop'>
			
			
			
			
            <a id='HyperLink5' href='JavaScript:window.close();'>Logout</a>
			</td>
    <td class='tdright'><a href='#ctl03_SkipLink'><img alt='Skip Navigation Links' src='http://magicquestion.corproot.net/MagicQuestion/WebResource.axd?d=BPQThposdZvlHkK_4-RW2YlZ2E2IO29oxOdh1dB7hDvTNVca8Cf7HGPWQMXi9bpxk9wp6lMY_gHEs0NXpTn4hgA6XihsIPZ36LoQS1XYyeM1&amp;t=635661302788714647' width='0' height='0' style='border-width:0px;' /></a><div class='topMenu' id='ctl03'>
	<ul class='level1'>
		<li><a class='popout level1' href='#' onclick='__doPostBack(&#39;ctl00$ctl03&#39;,&#39;Magic Question Menu&#39;)'>Magic Question Menu</a><ul class='level2 topMenu'>
			<li><a class='level2' href='CCAgent.aspx'>CCAgent</a></li>
		</ul></li>
	</ul>
</div><a id='ctl03_SkipLink'></a>
					<br />
					
			</td>
    </tr>
    </table>
    </div>
    <div class='Content'>
      

 	<table id='test'>
		<tr>
			<td class='tdtop'>
				<span id='ContentPH_lblUserAccount'>User Account (NT Login)</span>
			</td>
			<td>
				<input name='ctl00$ContentPH$txtSuchString' type='text' id='ContentPH_txtSuchString' value='{0}' style='margin-left: 0px' />
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type='submit' name='ctl00$ContentPH$btnSearch' value='User Account suchen' id='ContentPH_btnSearch' />
				
				<br />
			</td>
		</tr>
		<tr>
			<td class='tdtop'>
				<span id='ContentPH_lblMandant'>Mandant</span>
			</td>
			<td><span id='ContentPH_lblMandantName'></span></td>
			</tr>
		<tr>
			<td colspan='2'>
				<table id='ContentPH_rblMantator'>
	<tr>
		<td><input id='ContentPH_rblMantator_0' type='radio' name='ctl00$ContentPH$rblMantator' value='65' /><label for='ContentPH_rblMantator_0'><nobr>Aargauische Kantonalbank</nobr></label></td><td><input id='ContentPH_rblMantator_20' type='radio' name='ctl00$ContentPH$rblMantator' value='37' /><label for='ContentPH_rblMantator_20'><nobr>BBO</nobr></label></td><td><input id='ContentPH_rblMantator_40' type='radio' name='ctl00$ContentPH$rblMantator' value='111' /><label for='ContentPH_rblMantator_40'><nobr>GRB Glarner Regionalbank</nobr></label></td><td><input id='ContentPH_rblMantator_60' type='radio' name='ctl00$ContentPH$rblMantator' value='55' /><label for='ContentPH_rblMantator_60'><nobr>Mobiliar</nobr></label></td><td><input id='ContentPH_rblMantator_80' type='radio' name='ctl00$ContentPH$rblMantator' value='19' /><label for='ContentPH_rblMantator_80'><nobr>St.Galler Kantonalbank</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_1' type='radio' name='ctl00$ContentPH$rblMantator' value='43' /><label for='ContentPH_rblMantator_1'><nobr>ABS Alternative Bank Schweiz</nobr></label></td><td><input id='ContentPH_rblMantator_21' type='radio' name='ctl00$ContentPH$rblMantator' value='110' /><label for='ContentPH_rblMantator_21'><nobr>Bernerland Bank AG</nobr></label></td><td><input id='ContentPH_rblMantator_41' type='radio' name='ctl00$ContentPH$rblMantator' value='75' /><label for='ContentPH_rblMantator_41'><nobr>Griesser AG</nobr></label></td><td><input id='ContentPH_rblMantator_61' type='radio' name='ctl00$ContentPH$rblMantator' value='51' /><label for='ContentPH_rblMantator_61'><nobr>Moevenpick</nobr></label></td><td><input id='ContentPH_rblMantator_81' type='radio' name='ctl00$ContentPH$rblMantator' value='1' checked='checked' /><label for='ContentPH_rblMantator_81'><nobr>Swisscom</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_2' type='radio' name='ctl00$ContentPH$rblMantator' value='88' /><label for='ContentPH_rblMantator_2'><nobr>Accenture Services AG</nobr></label></td><td><input id='ContentPH_rblMantator_22' type='radio' name='ctl00$ContentPH$rblMantator' value='26' /><label for='ContentPH_rblMantator_22'><nobr>BIS</nobr></label></td><td><input id='ContentPH_rblMantator_42' type='radio' name='ctl00$ContentPH$rblMantator' value='103' /><label for='ContentPH_rblMantator_42'><nobr>GSMN Suisse SA</nobr></label></td><td><input id='ContentPH_rblMantator_62' type='radio' name='ctl00$ContentPH$rblMantator' value='24' /><label for='ContentPH_rblMantator_62'><nobr>Previon AG</nobr></label></td><td><input id='ContentPH_rblMantator_82' type='radio' name='ctl00$ContentPH$rblMantator' value='27' /><label for='ContentPH_rblMantator_82'><nobr>Swisslos</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_3' type='radio' name='ctl00$ContentPH$rblMantator' value='80' /><label for='ContentPH_rblMantator_3'><nobr>acrevis Bank AG</nobr></label></td><td><input id='ContentPH_rblMantator_23' type='radio' name='ctl00$ContentPH$rblMantator' value='30' /><label for='ContentPH_rblMantator_23'><nobr>BKT Bank Thalwil</nobr></label></td><td><input id='ContentPH_rblMantator_43' type='radio' name='ctl00$ContentPH$rblMantator' value='23' /><label for='ContentPH_rblMantator_43'><nobr>Hyposwiss</nobr></label></td><td><input id='ContentPH_rblMantator_63' type='radio' name='ctl00$ContentPH$rblMantator' value='91' /><label for='ContentPH_rblMantator_63'><nobr>Priora AG</nobr></label></td><td><input id='ContentPH_rblMantator_83' type='radio' name='ctl00$ContentPH$rblMantator' value='59' /><label for='ContentPH_rblMantator_83'><nobr>Swissregiobank AG</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_4' type='radio' name='ctl00$ContentPH$rblMantator' value='32' /><label for='ContentPH_rblMantator_4'><nobr>AEK Thun</nobr></label></td><td><input id='ContentPH_rblMantator_24' type='radio' name='ctl00$ContentPH$rblMantator' value='104' /><label for='ContentPH_rblMantator_24'><nobr>BLS AG</nobr></label></td><td><input id='ContentPH_rblMantator_44' type='radio' name='ctl00$ContentPH$rblMantator' value='22' /><label for='ContentPH_rblMantator_44'><nobr>IBM</nobr></label></td><td><input id='ContentPH_rblMantator_64' type='radio' name='ctl00$ContentPH$rblMantator' value='25' /><label for='ContentPH_rblMantator_64'><nobr>RBS Coutts</nobr></label></td><td><input id='ContentPH_rblMantator_84' type='radio' name='ctl00$ContentPH$rblMantator' value='13' /><label for='ContentPH_rblMantator_84'><nobr>Tamedia</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_5' type='radio' name='ctl00$ContentPH$rblMantator' value='56' /><label for='ContentPH_rblMantator_5'><nobr>Alpha Rheintal Bank AG</nobr></label></td><td><input id='ContentPH_rblMantator_25' type='radio' name='ctl00$ContentPH$rblMantator' value='38' /><label for='ContentPH_rblMantator_25'><nobr>BSPK Dielsdorf</nobr></label></td><td><input id='ContentPH_rblMantator_45' type='radio' name='ctl00$ContentPH$rblMantator' value='81' /><label for='ContentPH_rblMantator_45'><nobr>IG Leasing AG</nobr></label></td><td><input id='ContentPH_rblMantator_65' type='radio' name='ctl00$ContentPH$rblMantator' value='63' /><label for='ContentPH_rblMantator_65'><nobr>Resource AG</nobr></label></td><td><input id='ContentPH_rblMantator_85' type='radio' name='ctl00$ContentPH$rblMantator' value='79' /><label for='ContentPH_rblMantator_85'><nobr>The Swatch Group Services Ltd</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_6' type='radio' name='ctl00$ContentPH$rblMantator' value='90' /><label for='ContentPH_rblMantator_6'><nobr>Alpiq AG</nobr></label></td><td><input id='ContentPH_rblMantator_26' type='radio' name='ctl00$ContentPH$rblMantator' value='105' /><label for='ContentPH_rblMantator_26'><nobr>Burgerliche Ersparniskasse Bern</nobr></label></td><td><input id='ContentPH_rblMantator_46' type='radio' name='ctl00$ContentPH$rblMantator' value='85' /><label for='ContentPH_rblMantator_46'><nobr>IKEA Service Center NV</nobr></label></td><td><input id='ContentPH_rblMantator_66' type='radio' name='ctl00$ContentPH$rblMantator' value='34' /><label for='ContentPH_rblMantator_66'><nobr>RSO</nobr></label></td><td><input id='ContentPH_rblMantator_86' type='radio' name='ctl00$ContentPH$rblMantator' value='18' /><label for='ContentPH_rblMantator_86'><nobr>Thurgauer Kantonalbank</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_7' type='radio' name='ctl00$ContentPH$rblMantator' value='9' /><label for='ContentPH_rblMantator_7'><nobr>Ascom</nobr></label></td><td><input id='ContentPH_rblMantator_27' type='radio' name='ctl00$ContentPH$rblMantator' value='7' /><label for='ContentPH_rblMantator_27'><nobr>Certas</nobr></label></td><td><input id='ContentPH_rblMantator_47' type='radio' name='ctl00$ContentPH$rblMantator' value='52' /><label for='ContentPH_rblMantator_47'><nobr>Implenia Management AG</nobr></label></td><td><input id='ContentPH_rblMantator_67' type='radio' name='ctl00$ContentPH$rblMantator' value='113' /><label for='ContentPH_rblMantator_67'><nobr>SB Saanen Bank AG</nobr></label></td><td><input id='ContentPH_rblMantator_87' type='radio' name='ctl00$ContentPH$rblMantator' value='83' /><label for='ContentPH_rblMantator_87'><nobr>TUS AG</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_8' type='radio' name='ctl00$ContentPH$rblMantator' value='62' /><label for='ContentPH_rblMantator_8'><nobr>AVIGA AG</nobr></label></td><td><input id='ContentPH_rblMantator_28' type='radio' name='ctl00$ContentPH$rblMantator' value='17' /><label for='ContentPH_rblMantator_28'><nobr>Credit Suisse</nobr></label></td><td><input id='ContentPH_rblMantator_48' type='radio' name='ctl00$ContentPH$rblMantator' value='5' /><label for='ContentPH_rblMantator_48'><nobr>Infonet</nobr></label></td><td><input id='ContentPH_rblMantator_68' type='radio' name='ctl00$ContentPH$rblMantator' value='48' /><label for='ContentPH_rblMantator_68'><nobr>SBB</nobr></label></td><td><input id='ContentPH_rblMantator_88' type='radio' name='ctl00$ContentPH$rblMantator' value='28' /><label for='ContentPH_rblMantator_88'><nobr>UEFA</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_9' type='radio' name='ctl00$ContentPH$rblMantator' value='46' /><label for='ContentPH_rblMantator_9'><nobr>AXA</nobr></label></td><td><input id='ContentPH_rblMantator_29' type='radio' name='ctl00$ContentPH$rblMantator' value='84' /><label for='ContentPH_rblMantator_29'><nobr>DZ PRIVATBANK</nobr></label></td><td><input id='ContentPH_rblMantator_49' type='radio' name='ctl00$ContentPH$rblMantator' value='54' /><label for='ContentPH_rblMantator_49'><nobr>Inselspital Bern</nobr></label></td><td><input id='ContentPH_rblMantator_69' type='radio' name='ctl00$ContentPH$rblMantator' value='87' /><label for='ContentPH_rblMantator_69'><nobr>Sberbank (Switzerland) AG</nobr></label></td><td><input id='ContentPH_rblMantator_89' type='radio' name='ctl00$ContentPH$rblMantator' value='53' /><label for='ContentPH_rblMantator_89'><nobr>Unia</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_10' type='radio' name='ctl00$ContentPH$rblMantator' value='35' /><label for='ContentPH_rblMantator_10'><nobr>Bank aek Genossenschaft</nobr></label></td><td><input id='ContentPH_rblMantator_30' type='radio' name='ctl00$ContentPH$rblMantator' value='39' /><label for='ContentPH_rblMantator_30'><nobr>EK Interlaken</nobr></label></td><td><input id='ContentPH_rblMantator_50' type='radio' name='ctl00$ContentPH$rblMantator' value='14' /><label for='ContentPH_rblMantator_50'><nobr>ISS Schweiz</nobr></label></td><td><input id='ContentPH_rblMantator_70' type='radio' name='ctl00$ContentPH$rblMantator' value='15' /><label for='ContentPH_rblMantator_70'><nobr>Schweiz. Dienstleistungszentrum</nobr></label></td><td><input id='ContentPH_rblMantator_90' type='radio' name='ctl00$ContentPH$rblMantator' value='50' /><label for='ContentPH_rblMantator_90'><nobr>Unisys</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_11' type='radio' name='ctl00$ContentPH$rblMantator' value='108' /><label for='ContentPH_rblMantator_11'><nobr>Bank BSU Genossenschaft</nobr></label></td><td><input id='ContentPH_rblMantator_31' type='radio' name='ctl00$ContentPH$rblMantator' value='40' /><label for='ContentPH_rblMantator_31'><nobr>EK Rüeggisberg</nobr></label></td><td><input id='ContentPH_rblMantator_51' type='radio' name='ctl00$ContentPH$rblMantator' value='10' /><label for='ContentPH_rblMantator_51'><nobr>IT-SDL</nobr></label></td><td><input id='ContentPH_rblMantator_71' type='radio' name='ctl00$ContentPH$rblMantator' value='2' /><label for='ContentPH_rblMantator_71'><nobr>Securitas</nobr></label></td><td><input id='ContentPH_rblMantator_91' type='radio' name='ctl00$ContentPH$rblMantator' value='29' /><label for='ContentPH_rblMantator_91'><nobr>Universitäts Spital</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_12' type='radio' name='ctl00$ContentPH$rblMantator' value='57' /><label for='ContentPH_rblMantator_12'><nobr>Bank CA St.Gallen AG</nobr></label></td><td><input id='ContentPH_rblMantator_32' type='radio' name='ctl00$ContentPH$rblMantator' value='66' /><label for='ContentPH_rblMantator_32'><nobr>Entris Banking AG</nobr></label></td><td><input id='ContentPH_rblMantator_52' type='radio' name='ctl00$ContentPH$rblMantator' value='74' /><label for='ContentPH_rblMantator_52'><nobr>Jura Management</nobr></label></td><td><input id='ContentPH_rblMantator_72' type='radio' name='ctl00$ContentPH$rblMantator' value='3' /><label for='ContentPH_rblMantator_72'><nobr>Securiton</nobr></label></td><td><input id='ContentPH_rblMantator_92' type='radio' name='ctl00$ContentPH$rblMantator' value='31' /><label for='ContentPH_rblMantator_92'><nobr>UPU</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_13' type='radio' name='ctl00$ContentPH$rblMantator' value='76' /><label for='ContentPH_rblMantator_13'><nobr>Bank Coop (BCB)</nobr></label></td><td><input id='ContentPH_rblMantator_33' type='radio' name='ctl00$ContentPH$rblMantator' value='8' /><label for='ContentPH_rblMantator_33'><nobr>EOS</nobr></label></td><td><input id='ContentPH_rblMantator_53' type='radio' name='ctl00$ContentPH$rblMantator' value='11' /><label for='ContentPH_rblMantator_53'><nobr>KPT</nobr></label></td><td><input id='ContentPH_rblMantator_73' type='radio' name='ctl00$ContentPH$rblMantator' value='4' /><label for='ContentPH_rblMantator_73'><nobr>Securitus</nobr></label></td><td><input id='ContentPH_rblMantator_93' type='radio' name='ctl00$ContentPH$rblMantator' value='47' /><label for='ContentPH_rblMantator_93'><nobr>Verwaltungs- und Privat-Bank AG</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_14' type='radio' name='ctl00$ContentPH$rblMantator' value='36' /><label for='ContentPH_rblMantator_14'><nobr>Bank EEK</nobr></label></td><td><input id='ContentPH_rblMantator_34' type='radio' name='ctl00$ContentPH$rblMantator' value='106' /><label for='ContentPH_rblMantator_34'><nobr>Equilas AG</nobr></label></td><td><input id='ContentPH_rblMantator_54' type='radio' name='ctl00$ContentPH$rblMantator' value='49' /><label for='ContentPH_rblMantator_54'><nobr>Lexmark</nobr></label></td><td><input id='ContentPH_rblMantator_74' type='radio' name='ctl00$ContentPH$rblMantator' value='6' /><label for='ContentPH_rblMantator_74'><nobr>SHOP</nobr></label></td><td><input id='ContentPH_rblMantator_94' type='radio' name='ctl00$ContentPH$rblMantator' value='44' /><label for='ContentPH_rblMantator_94'><nobr>VZ Depotbank</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_15' type='radio' name='ctl00$ContentPH$rblMantator' value='77' /><label for='ContentPH_rblMantator_15'><nobr>Bank Julius Bär & Co. Ltd.</nobr></label></td><td><input id='ContentPH_rblMantator_35' type='radio' name='ctl00$ContentPH$rblMantator' value='45' /><label for='ContentPH_rblMantator_35'><nobr>Esprit Netzwerk AG</nobr></label></td><td><input id='ContentPH_rblMantator_55' type='radio' name='ctl00$ContentPH$rblMantator' value='93' /><label for='ContentPH_rblMantator_55'><nobr>Lienhard Office Group AG</nobr></label></td><td><input id='ContentPH_rblMantator_75' type='radio' name='ctl00$ContentPH$rblMantator' value='41' /><label for='ContentPH_rblMantator_75'><nobr>SL Bucheggberg</nobr></label></td><td><input id='ContentPH_rblMantator_95' type='radio' name='ctl00$ContentPH$rblMantator' value='92' /><label for='ContentPH_rblMantator_95'><nobr>WEIDPLAS GmbH</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_16' type='radio' name='ctl00$ContentPH$rblMantator' value='109' /><label for='ContentPH_rblMantator_16'><nobr>Bank SLM AG</nobr></label></td><td><input id='ContentPH_rblMantator_36' type='radio' name='ctl00$ContentPH$rblMantator' value='73' /><label for='ContentPH_rblMantator_36'><nobr>Finanzdepartement Kt. BS</nobr></label></td><td><input id='ContentPH_rblMantator_56' type='radio' name='ctl00$ContentPH$rblMantator' value='119' /><label for='ContentPH_rblMantator_56'><nobr>Lienhard und Partner Privatbank </nobr></label></td><td><input id='ContentPH_rblMantator_76' type='radio' name='ctl00$ContentPH$rblMantator' value='42' /><label for='ContentPH_rblMantator_76'><nobr>SL Frutigen</nobr></label></td><td><input id='ContentPH_rblMantator_96' type='radio' name='ctl00$ContentPH$rblMantator' value='89' /><label for='ContentPH_rblMantator_96'><nobr>Winterthur G&D</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_17' type='radio' name='ctl00$ContentPH$rblMantator' value='33' /><label for='ContentPH_rblMantator_17'><nobr>Bank Thalwil</nobr></label></td><td><input id='ContentPH_rblMantator_37' type='radio' name='ctl00$ContentPH$rblMantator' value='60' /><label for='ContentPH_rblMantator_37'><nobr>Finanzlogistik AG</nobr></label></td><td><input id='ContentPH_rblMantator_57' type='radio' name='ctl00$ContentPH$rblMantator' value='86' /><label for='ContentPH_rblMantator_57'><nobr>Loeb AG</nobr></label></td><td><input id='ContentPH_rblMantator_77' type='radio' name='ctl00$ContentPH$rblMantator' value='107' /><label for='ContentPH_rblMantator_77'><nobr>Spar+Leihkasse Riggisberg AG</nobr></label></td><td><input id='ContentPH_rblMantator_97' type='radio' name='ctl00$ContentPH$rblMantator' value='78' /><label for='ContentPH_rblMantator_97'><nobr>WIR Bank</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_18' type='radio' name='ctl00$ContentPH$rblMantator' value='64' /><label for='ContentPH_rblMantator_18'><nobr>Banque Cantonale de Genève (BCGE)</nobr></label></td><td><input id='ContentPH_rblMantator_38' type='radio' name='ctl00$ContentPH$rblMantator' value='16' /><label for='ContentPH_rblMantator_38'><nobr>Finnova</nobr></label></td><td><input id='ContentPH_rblMantator_58' type='radio' name='ctl00$ContentPH$rblMantator' value='20' /><label for='ContentPH_rblMantator_58'><nobr>Luzerner Kantonalbank</nobr></label></td><td><input id='ContentPH_rblMantator_78' type='radio' name='ctl00$ContentPH$rblMantator' value='112' /><label for='ContentPH_rblMantator_78'><nobr>Sparkasse Schwyz AG</nobr></label></td><td><input id='ContentPH_rblMantator_98' type='radio' name='ctl00$ContentPH$rblMantator' value='82' /><label for='ContentPH_rblMantator_98'><nobr>Xentive SA</nobr></label></td>
	</tr><tr>
		<td><input id='ContentPH_rblMantator_19' type='radio' name='ctl00$ContentPH$rblMantator' value='61' /><label for='ContentPH_rblMantator_19'><nobr>Basler Kantonalbank (BKB)</nobr></label></td><td><input id='ContentPH_rblMantator_39' type='radio' name='ctl00$ContentPH$rblMantator' value='21' /><label for='ContentPH_rblMantator_39'><nobr>Freiburger Kantonalbank</nobr></label></td><td><input id='ContentPH_rblMantator_59' type='radio' name='ctl00$ContentPH$rblMantator' value='102' /><label for='ContentPH_rblMantator_59'><nobr>Mirabaud Asset Management SA</nobr></label></td><td><input id='ContentPH_rblMantator_79' type='radio' name='ctl00$ContentPH$rblMantator' value='58' /><label for='ContentPH_rblMantator_79'><nobr>Sparkasse Wiesendangen</nobr></label></td><td></td>
	</tr>
</table>
			</td>
		</tr>
	</table>
	
	<input type='hidden' name='ctl00$ContentPH$hdUsedQuestions' id='ContentPH_hdUsedQuestions' />
	<br />
		

    </div>
    
<script type='text/javascript'>
document.getElementById('ContentPH_btnSearch').click();
</script>
</form>
</body>
</html>

";
    public static Dictionary<string, Dictionary<string, Dictionary<string, string>>> myTemplates = new Dictionary<string, Dictionary<string, Dictionary<string, string>>> {

        { "corproot",
           new Dictionary<string, Dictionary<string, string>>{
               { "DE",
                   new Dictionary<string, string>{
                       {"subject", " // Bestätigung des Vorgesetzten zur Neusetzung eines Passwortes von " },
                       {"body",@"                 
Sehr geehrte/r Vorgesetzte/r
Aus Sicherheitsgründen benötigen wir von Ihnen ein schriftliches Einverständnis für das Neusetzen eines Passworts.
Indem Sie uns dieses Mail ausgefüllt zurückschicken, bestätigen Sie, dass Sie der/die Vorgesetzte/r des Inhabers des untenstehenden Accounts sind.
Wir bitten Sie, die unten angegebenen Informationen zu ergänzen und uns dieses Mail an Service Desk IT (mailto:it.servicedesk@swisscom.com) weiterzuleiten. 

Für welche Applikation / System wird ein neues Passwort benötigt: Corproot / NT 
NT-Account oder User-ID der/die zurückgesetzt werden soll: {0}
Inhaber dieses Accounts: {1}
Firma: {2}
Telefonnummer auf welcher dem Benutzer das neue Passwort mitgeteilt werden kann: {3}
___________________________________________________________________________


Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },
               { "FR",
                   new Dictionary<string, string>{
                       {"subject", " // Vous confirmez être le (la) supérieur(e) du détenteur du compte ci-dessous" },
                       {"body",@"
Madame, Monsieur, 
Pour des raisons de sécurité, nous avons besoin de votre accord écrit pour la création d'un nouveau mot de passe. 
En nous renvoyant ce mail, vous confirmez être le (la) supérieur(e) du détenteur du compte ci-dessous ainsi que le (la) responsable en cas d’utilisation abusive. 
Nous vous prions de compléter les informations dont nous avons besoin et de faire suivre ce mail au Service Desk IT (it.servicedesk@swisscom.com). 

Pour quelle application / quel système, le nouveau mot de passe est-il demandé?: Corproot / NT
Compte NT ou ID utilisateur qui a besoin d'un nouveau mot de passe: {0}
L'utilisateur de ce compte NT: {1}
Entreprise: {2}
Numéro de téléphone par lequel le nouveau mot de passe peut être communiqué à l'utilisateur: {3}
___________________________________________________________________________

Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },
               { "IT",
                   new Dictionary<string, string>{
                       {"subject", " // Lei conferma di essere il (la) responsabile del titolare dell’account qui sotto " },
                       {"body",@"
Gentile superiore

Per motivi di sicurezza abbiamo bisogno della sua conferma per reimpostare la sua password.
Rispondendo a questo mail, conferma che lei è il superiore del titolare dell’account menzionato qui sotto.
Non appena ricevuta sua conferma al Service Desk IT (mailto: it.servicedesk@swisscom.com), contatteremo il cliente per comunicargli la nuova password.

Quale applicazione / sistema, è necessaria una nuova password : Corproot / NT
NT-Account o User ID di / è da resettare : {0}
Proprietario di questo account : {1}
Azienda : {2}
Numero di telefono al quale l'utente può essere informato della nuova password : {3} 

___________________________________________________________________________

Telefono 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 
" }
                   }
               },
               { "EN",
                   new Dictionary<string, string>{
                       {"subject",  " // Line manager confirmation to reset password for account "  },
                       {"body",@"
Dear line manager
Due to security reasons we need a confirmation in written form for a password reset. Please return this E-Mail filled out to us and confirm that you are the line manager of the below mentioned account owner. We kindly ask you to complete the subsequent information and to return this E-Mail to the Service Desk IT (mailto:it.servicedesk@swisscom.com). 

Password reset needed for application / system: Corproot / NT
NT-Account or User-ID which should be reset: {0}
Account owner: {1}
Company:  {2}
Phone number from the user (required to communicate the new password to the user): {3}
___________________________________________________________________________

Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },

            }
        },
        { "itoper",
           new Dictionary<string, Dictionary<string, string>>{
               { "DE",
                   new Dictionary<string, string>{
                       {"subject", " // Bestätigung des Vorgesetzten zur Neusetzung eines Passwortes von " },
                       {"body",@"                 
Sehr geehrte/r Vorgesetzte/r
Aus Sicherheitsgründen benötigen wir von Ihnen ein schriftliches Einverständnis für das Neusetzen eines Passworts.
Indem Sie uns dieses Mail ausgefüllt zurückschicken, bestätigen Sie, dass Sie der/die Vorgesetzte/r des Inhabers des untenstehenden Accounts sind.
Wir bitten Sie, die unten angegebenen Informationen zu ergänzen und uns dieses Mail an Service Desk IT (mailto:it.servicedesk@swisscom.com) weiterzuleiten.

Für welche Applikation / System wird ein neues Passwort benötigt: ITOPER  
NT-Account oder User-ID der/die zurückgesetzt werden soll: {0}
Inhaber dieses Accounts: {1}
Firma: {2}
Telefonnummer auf welcher dem Benutzer das neue Passwort mitgeteilt werden kann: {3}
___________________________________________________________________________


Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },
               { "FR",
                   new Dictionary<string, string>{
                       {"subject", " // Vous confirmez être le (la) supérieur(e) du détenteur du compte ci-dessous" },
                       {"body",@"
Madame, Monsieur, 
Pour des raisons de sécurité, nous avons besoin de votre accord écrit pour la création d'un nouveau mot de passe. 
En nous renvoyant ce mail, vous confirmez être le (la) supérieur(e) du détenteur du compte ci-dessous ainsi que le (la) responsable en cas d’utilisation abusive. 
Nous vous prions de compléter les informations dont nous avons besoin et de faire suivre ce mail au Service Desk IT (it.servicedesk@swisscom.com). 

Pour quelle application / quel système, le nouveau mot de passe est-il demandé?: ITOPER 
Compte NT ou ID utilisateur qui a besoin d'un nouveau mot de passe: {0}
L'utilisateur de ce compte NT: {1}
Entreprise: {2}
Numéro de téléphone par lequel le nouveau mot de passe peut être communiqué à l'utilisateur: {3}
___________________________________________________________________________

Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },
               { "IT",
                   new Dictionary<string, string>{
                       {"subject", " // Lei conferma di essere il (la) responsabile del titolare dell’account qui sotto " },
                       {"body",@"
Gentile superiore

Per motivi di sicurezza abbiamo bisogno della sua conferma per reimpostare la sua password.
Rispondendo a questo mail, conferma che lei è il superiore del titolare dell’account menzionato qui sotto.
Non appena ricevuta sua conferma al Service Desk IT (mailto: it.servicedesk@swisscom.com), contatteremo il cliente per comunicargli la nuova password.

Quale applicazione / sistema, è necessaria una nuova password : ITOPER 
NT-Account o User ID di / è da resettare : {0}
Proprietario di questo account : {1}
Azienda : {2}
Numero di telefono al quale l'utente può essere informato della nuova password : {3} 

___________________________________________________________________________

Telefono 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 
" }
                   }
               },
               { "EN",
                   new Dictionary<string, string>{
                       {"subject",  " // Line manager confirmation to reset password for account "  },
                       {"body",@"
Dear line manager
Due to security reasons we need a confirmation in written form for a password reset. Please return this E-Mail filled out to us and confirm that you are the line manager of the below mentioned account owner. We kindly ask you to complete the subsequent information and to return this E-Mail to the Service Desk IT (mailto:it.servicedesk@swisscom.com). 

Password reset needed for application / system: ITOPER 
NT-Account or User-ID which should be reset: {0}
Account owner: {1}
Company:  {2}
Phone number from the user (required to communicate the new password to the user): {3}
___________________________________________________________________________

Telefon 0800 810 410 
Fax 031 939 84 27 
servicedesk.it@swisscom.com 
____________________________________ 

Swisscom (Schweiz) AG 
Enterprise Customers 
Customer Service Desk 
Technical End User Service Desk 

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern
" }
                   }
               },

            }
        },
        { "reactivate",
           new Dictionary<string, Dictionary<string, string>>{
               { "DE",
                   new Dictionary<string, string>{
                       {"subject", " // Bestätigung des Vorgesetzten zur befristeten Reaktivierung des Accounts von " },
                       {"body",@"
Sehr geehrte/r Vorgesetzte/r

Aus Sicherheitsgründen benötigen wir von Ihnen ein schriftliches Einverständnis für die befristete Reaktivierung des Useraccounts.
Indem Sie uns dieses Mail zurückschicken, bestätigen Sie, dass Sie der/die Vorgesetzte/r des Inhabers des untenstehenden Accounts sind.
Wir bitten Sie, die unten angegebenen Informationen zu prüfen, gegebenenfalls zu korrigieren und uns dieses Mail an Service Desk IT (mailto:it.servicedesk@swisscom.com) zurückzusenden.

Account oder User-ID der reaktiviert werden soll: {0}
Inhaber dieses Accounts:{1}

Mit dieser Aktion wird der Account nur befristet reaktiviert und nach spätestens 14 Tagen automatisch wieder deaktiviert. Um dies zu verhindern, müssen sie innert dieser Frist eine Verlängerung des Personaldatensatzes erwirken.

Mit freundlichen Grüssen

Service Desk IT

Swisscom (Schweiz) AG 
Enterprise Customers 
Enterprise Customer Care
Customer Care Central

Telefon 0800 810 410 
servicedesk.it@swisscom.com

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern

" }
                   }
               },
               { "FR",
                   new Dictionary<string, string>{
                       {"subject", " // Confirmation du supérieur pour la réactivation temporaire du compte " },
                       {"body",@"
Madame, Monsieur,

Pour des raisons de sécurité, nous avons besoin de votre accord par écrit pour la réactivation temporaire.
En nous renvoyant ce mail, vous confirmez être le (la) supérieur(e) du détenteur du compte ci-dessous
Nous vous prions de compléter les informations dont nous avons besoin et de faire suivre ce mail au Service Desk IT (it.servicedesk@swisscom.com).

Compte NT ou ID utilisateur à réactiver: {0}
L'utilisateur de ce compte NT: {1}

Avec cette action, le compte ne sera réactivé que pour une durée limitée et automatiquement désactivé de nouveau au bout de 14 jours.
Afin d'empêcher la désactivation à nouveau, veuillez renouveler le dossier de donnée personnelles pendant ce temps.

Meilleures salutations

Service Desk IT

Swisscom (Schweiz) AG 
Enterprise Customers 
Enterprise Customer Care
Customer Care Central

Telefon 0800 810 410 
servicedesk.it@swisscom.com

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postadresse: 
Postfach 
CH-3050 Bern



" }
                   }
               },
               { "IT",
                   new Dictionary<string, string>{
                       {"subject", " // Consenso per la riattivazione temporanea del account utente " },
                       {"body",@"
Gentili superiori

Per motivi di sicurezza, abbiamo bisogno del vostro consenso scritto per la riattivazione temporanea del account utente.
Compilando questa mail e rispedendola a noi come il responsabile, confermi che il conto sottostante è il proprietario del conto.
La preghiamo di controllare le informazioni qui sotto, di correggerle se necessario e di rispedirle al Service Desk IT (mailto:it.servicedesk@swisscom.com).

Account o ID utente da riattivare: {0} 
Proprietario di questo conto: {1}

Con questa azione l'account viene riattivato solo temporaneamente, e dopo 14 giorni il account sarà disattivato automaticamente. Per evitarlo, li preghiamo di inviare i dati personali in questa epoca di 14 giorni.

Cordiali saluti

Service Desk IT

Swisscom (Schweiz) AG 
Enterprise Customers 
Enterprise Customer Care
Customer Care Central

Telefono 0800 810 410 
servicedesk.it@swisscom.com

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 


" }
                   }
               },
               { "EN",
                   new Dictionary<string, string>{
                       {"subject",  " // Line manager confirmation to temporarily reactivate the user account of  "  },
                       {"body",@"
Dear line manager

Due to security reasons we need a confirmation in written form to temporarily reactivate the user account in question.
Please return this e-mail and confirm that you are the line manager of the below mentioned account owner.
We kindly ask you to check the subsequent information, possibly correct it and return this e-mail to the Service Desk IT (mailto: it.servicedesk@swisscom.com)

Account of User-ID which should be reactivated: {0}
Account owner:{1}

Please be aware that with this action the user account will be reactivated only temporarily and will automatically be deactivated again after 14 days. To prevent this, you will have to obtain a renewal of the personal data record within this 14 days deadline.

Best regards

Service Desk IT

Swisscom (Schweiz) AG 
Enterprise Customers 
Enterprise Customer Care
Customer Care Central

Phone 0800 810 410 
servicedesk.it@swisscom.com

Ey 10 
CHF-3063 Ittigen 

www.swisscom.ch/enterprises 

Postal address:
P. O. Box
CH-3050 Berne


" }
                   }
               },

            }
        },

    };
   
}
 
namespace bmail
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {

        public static string language = "DE";

        public MainWindow()
        {
            InitializeComponent();
        }
        private void buttonRetrieve_Click(object sender, RoutedEventArgs e)
        {
            /* see http://zetcode.com/articles/csharpreadwebpage/ */
            string html = string.Empty;
            string userid = textUserId.Text.ToString().ToUpper();
            string url = "https://collaboration.swisscom.com/SwisscomPerson.aspx?accountname=CORPROOT%5C" + userid;
            if (userid.ToLower().Contains("ext")) {
                url = "http://it-intra/ras/scripts/RAS_Info.asp?NTAccount=" + userid + "&SearchSubmit=Suchen";
            }

            Console.WriteLine(System.Security.Principal.WindowsIdentity.GetCurrent().Name);
            Console.WriteLine(System.Net.CredentialCache.DefaultNetworkCredentials);
            /* trying to read into the sharepoint server - not working now */
            /*userCredentials = System.Net.CredentialCache.DefaultNetworkCredentials;*/
            // ClientContext context = new ClientContext( url );
            //context.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials; /*userCredentials;
            /*
            */

            /*
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                html = reader.ReadToEnd();
            }
            */

            Console.WriteLine(url);
            Console.WriteLine(html);
            string message = "trying to retrieve informations for ";

            /* see https://blogs.msdn.microsoft.com/peterj/2008/01/23/creating-folders-and-adding-files-to-sharepoint-document-library/ */
            /*
            SPSite site = new Microsoft.SharePoint.SPSite("https://collaboration.swisscom.com/communities/fondue-lovers/SitePages/Community-Startseite.aspx");
            SPWeb spWeb = site.RootWeb;

            SPList docLib = spWeb.Lists["My Document Library"];
            SPListItem folder = docLib.Folders.Add(docLib.RootFolder.ServerRelativeUrl, SPFileSystemObjectType.Folder, "My folder");
            folder.Update();

            using (FileStream fs = File.OpenRead(@"C:\TestDoc.doc"))
            {
                SPFile file = folder.Folder.Files.Add("TestDoc.doc", fs);
                file.Update();
            }
            */
            System.Diagnostics.Process.Start("iexplore", url);
            //MessageBoxResult result = MessageBox.Show(message + textUserId.Text.ToString().ToUpper() );
        }

        /* see https://www.developerhandbook.com/c-sharp/how-to-create-a-new-outlook-2013-email-using-c-in-3-simple-steps/ */
        private MailItem prepareEmail(MailItem myMail, string subject, string body)
        {

            myMail.SentOnBehalfOfName = "servicedesk.it@swisscom.com";
            myMail.Reply = "Enterprise Customer Care <itsm.sn@swisscom.com>";
            myMail.To = textVorgesetzer.Text;
            myMail.Subject = textInc.Text + " " + subject + " " + textUserId.Text;
            myMail.Body = body;
            return myMail;
        }

        private void buttonInsall_Click(object sender, RoutedEventArgs e)
        {
            string collab_url = "https://collaboration.swisscom.com/projects/windows-10/Freigegebene%20Dokumente/Win10%20Programm/07%20Deployment%20Rollout/Rollout-Office/Self-Staging/Win10%20zu%20Win10%20Installationsanleitung/";
            string file_root = "Windows%2010%20zu%20Win10%20Installationsanleitung%20";
            string file_ext = ".pdf";
            string blank_line = @"

";
            Dictionary<string, string> salutations = new Dictionary<string, string> ();
            salutations.Add("DE", @"

Mit freundlichen Grüssen
Service Desk IT
");
            salutations.Add("FR", @"

Meilleures salutations
Service Desk IT
");
            salutations.Add("IT", @"

Meilleures salutations
Service Desk IT
");
            salutations.Add("EN",@"

Best Regards
Service Desk IT
");
            OutlookApp outlookApp = new OutlookApp();
            MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);
            mailItem.SentOnBehalfOfName = "servicedesk.it@swisscom.com";
            mailItem.To = textUserId.Text ;
            mailItem.Subject = textInc.Text + " // Windows 10 Installation";
            mailItem.Body = blank_line + collab_url + file_root + language + file_ext + salutations[ language ];
            mailItem.Importance = OlImportance.olImportanceHigh;
            mailItem.Display(false);
        }


        private void buttonReactivate_Click(object sender, RoutedEventArgs e)
        {
            string subject = GlobalVariables.myTemplates["reactivate"][language]["subject"];
            string body = String.Format(GlobalVariables.myTemplates["reactivate"][language]["body"], textUserId.Text, textName.Text);

            OutlookApp outlookApp = new OutlookApp();
            MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);

            mailItem = prepareEmail(mailItem, subject, body);
            //Set a high priority to the message
            mailItem.Importance = OlImportance.olImportanceHigh;
            mailItem.Display(false);
        }

        private void buttonItoper_Click(object sender, RoutedEventArgs e)
        {
            string subject = GlobalVariables.myTemplates["itoper"][language]["subject"];
            string body = String.Format(GlobalVariables.myTemplates["itoper"][language]["body"], textUserId.Text, textName.Text, textFirm.Text , textPhone.Text);

            OutlookApp outlookApp = new OutlookApp();
            MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);

            mailItem = prepareEmail(mailItem, subject, body);
            //Set a high priority to the message
            mailItem.Importance = OlImportance.olImportanceHigh;
            mailItem.Display(false);
        }


       
        private void buttonCorproot_Click(object sender, RoutedEventArgs e)
        {
            string subject = GlobalVariables.myTemplates["corproot"][language]["subject"]; 
            string body = String.Format(GlobalVariables.myTemplates["corproot"][language]["body"], textUserId.Text, textName.Text, textFirm.Text , textPhone.Text);

            int procCount = 0;
            Process[] processlist = Process.GetProcessesByName("OUTLOOK");
            foreach (Process theprocess in processlist)
            {
                procCount++;
            }
            if (procCount == 0)
            {
                Process.Start("outlook.exe");
                MessageBoxResult result = MessageBox.Show( "Starting outlook, please reprepare the email!" );
            }
            else
            { 
                OutlookApp outlookApp = new OutlookApp();
                MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);

                mailItem = prepareEmail(mailItem, subject, body );
                //Set a high priority to the message
                mailItem.Importance = OlImportance.olImportanceHigh;
                mailItem.Display(false);
            }
        }

        private void cbDE_Checked(object sender, RoutedEventArgs e)
        {
            language = "DE";
        }

        private void cbFR_Checked(object sender, RoutedEventArgs e)
        {
            language = "FR";
        }

        private void cbIT_Checked(object sender, RoutedEventArgs e)
        {
            language = "IT";
        }

        private void cbEN_Checked(object sender, RoutedEventArgs e)
        {
            language = "EN";
        }

        private void buttonMagickQuestion_Click(object sender, RoutedEventArgs e)
        {
            string html = string.Empty;
            string userid = textUserId.Text.ToString().ToUpper();
            string url = "http://magicquestion.corproot.net/MagicQuestion/CCAgent.aspx&" + userid;

            //string htmlfile = string.Format(GlobalVariables.htmlcode, textUserId.Text);
            string htmlfile = GlobalVariables.htmlcode.Replace("{0}", textUserId.Text);
            //Console.WriteLine(GlobalVariables.htmlcode);
            string myTempFile = System.IO.Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid().ToString() + "launchMagickQuestion.html");
            System.Console.WriteLine(myTempFile);
            using (StreamWriter sw = new StreamWriter(myTempFile))
            {
                sw.WriteLine( htmlfile );
            };
            System.Diagnostics.Process.Start("iexplore", "file://" + myTempFile); //url);
            /*
            System.Type oType = System.Type.GetTypeFromProgID("InternetExplorer.Application");
            object IE = System.Activator.CreateInstance(oType);

            IE.GetType().InvokeMember("menubar", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 0 });
            IE.GetType().InvokeMember("toolbar", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 0 });
            IE.GetType().InvokeMember("statusBar", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 0 });
            IE.GetType().InvokeMember("addressbar", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 0 });
            IE.GetType().InvokeMember("Visible", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { true });
            IE.GetType().InvokeMember("Height", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 680 });
            IE.GetType().InvokeMember("Width", System.Reflection.BindingFlags.SetProperty, null, IE, new object[] { 1030 });
            IE.GetType().InvokeMember("Navigate", System.Reflection.BindingFlags.InvokeMethod, null, IE, new object[] { url });
            */
        }
    }
}
